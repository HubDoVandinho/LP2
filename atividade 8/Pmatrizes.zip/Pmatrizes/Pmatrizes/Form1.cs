﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            int[] vetor = new int[20];


            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("Digite um número", "Entrada de dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Numero inválido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
            { 
                auxiliar += x + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() {"Ana","André","Fátima","João","Janete","Otávio","Marcelo","Pedro","Thais"};
            lista.Remove("Otávio");
            string auxiliar = "";
            foreach (string s in lista)
            { 
                    auxiliar+= s + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            double media = 0;
            string imprimir = "";

            for (var aluno = 0; aluno < 20; aluno++)
            {
                for (var nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota (entre 0 a 10)", "Entrada de dados");

                    if (!double.TryParse(auxiliar, out notas[aluno, nota]))
                    {
                        MessageBox.Show("Dado inválido");
                        nota--;

                    }
                    else if (notas[aluno, nota] < 0 || notas[aluno, nota] > 10)
                    {
                        MessageBox.Show("Dado inválido (deve estar entre 0 e 10)");
                        nota--;
                    }
                    else
                    {
                        media = media + notas[aluno, nota];
                    }
                }

                media = media / 3.0;
                imprimir = imprimir + "Aluno " + (aluno +1) + " Média: " + media + "\n";
                media = 0;

            }
            MessageBox.Show(imprimir);


         
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 obj = new frmExercicio4();
            obj.Show();
        }
    }
}

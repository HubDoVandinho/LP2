﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] tamNomes = new int[10];
            int i = 0;
            string imprimir = "";

            for (i = 0; i < tamNomes.Length; i++) 
            {
                nomes[i] = Interaction.InputBox("Digite o nome", "");
                tamNomes[i] = nomes[i].Replace(" ","").Length;
                imprimir = imprimir + "O nome: " + nomes[i] + " tem " + tamNomes[i] + "." + "\n";  
            }
            MessageBox.Show(imprimir);

        }
    }
}

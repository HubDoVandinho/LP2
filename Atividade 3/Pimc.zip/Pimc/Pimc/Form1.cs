﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double altura, peso, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void lblAltura_Click(object sender, EventArgs e)
        {

        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out peso) || (peso <=0 ))
            {
                MessageBox.Show("Entrada inválida");
                mskbxPeso.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtImc.Clear();
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(mskbxAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Entrada inválida");
                mskbxAltura.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lblPeso_Click(object sender, EventArgs e)
        {

        }

        private void mskbxAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void lblImc_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            resultado = peso / (Math.Pow(altura, 2));
            txtImc.Text = resultado.ToString("N2");

            resultado = Math.Round(resultado, 1);

            if (resultado > 40)          
                MessageBox.Show("Obesidade grave (grau 3)");
            else 
            {
                if (resultado > 30 && resultado < 39.9)
                    MessageBox.Show("Obesidade (grau 2)");
                else
                {
                    if (resultado > 25 && resultado < 29.9)
                        MessageBox.Show("Sobrepeso (Grau 1)");
                    else
                    {
                        if (resultado > 18.9 && resultado < 24.9)
                            MessageBox.Show("Normal");
                        else
                        {
                            MessageBox.Show("Magreza");
                        }
                    }
                }
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

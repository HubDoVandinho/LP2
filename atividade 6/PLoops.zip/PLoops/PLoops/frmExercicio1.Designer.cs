﻿namespace PLoops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLetrasRep = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnEspaçoBranco = new System.Windows.Forms.Button();
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnLetrasRep
            // 
            this.btnLetrasRep.Location = new System.Drawing.Point(549, 292);
            this.btnLetrasRep.Name = "btnLetrasRep";
            this.btnLetrasRep.Size = new System.Drawing.Size(128, 49);
            this.btnLetrasRep.TabIndex = 8;
            this.btnLetrasRep.Text = "Letras repetidas";
            this.btnLetrasRep.UseVisualStyleBackColor = true;
            this.btnLetrasRep.Click += new System.EventHandler(this.btnLetrasRep_Click);
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(347, 292);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(128, 49);
            this.btnR.TabIndex = 7;
            this.btnR.Text = "Qntd R";
            this.btnR.UseVisualStyleBackColor = true;
            this.btnR.Click += new System.EventHandler(this.btnR_Click);
            // 
            // btnEspaçoBranco
            // 
            this.btnEspaçoBranco.Location = new System.Drawing.Point(155, 292);
            this.btnEspaçoBranco.Name = "btnEspaçoBranco";
            this.btnEspaçoBranco.Size = new System.Drawing.Size(128, 49);
            this.btnEspaçoBranco.TabIndex = 6;
            this.btnEspaçoBranco.Text = "Espaços em branco";
            this.btnEspaçoBranco.UseVisualStyleBackColor = true;
            this.btnEspaçoBranco.Click += new System.EventHandler(this.btnEspaçoBranco_Click);
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(188, 151);
            this.rchtxtFrase.MaxLength = 100;
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(464, 63);
            this.rchtxtFrase.TabIndex = 5;
            this.rchtxtFrase.Text = "";
            this.rchtxtFrase.TextChanged += new System.EventHandler(this.rchtxtFrase_TextChanged);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLetrasRep);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnEspaçoBranco);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLetrasRep;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnEspaçoBranco;
        private System.Windows.Forms.RichTextBox rchtxtFrase;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int cont, qntdR = 0;
            int tamanho = rchtxtFrase.Text.Length;

            for (cont = 0; cont < tamanho; cont++)
            {
                if (rchtxtFrase.Text[cont] == 'r' || rchtxtFrase.Text[cont] == 'R')
                    qntdR = qntdR + 1;
                else
                    qntdR = qntdR + 0;
            }
            MessageBox.Show("Sua frase tem " + qntdR + " R e/ou r");
        }

        private void btnEspaçoBranco_Click(object sender, EventArgs e)
        {
            int cont = 0, qntdEspaco = 0;
            int tamanho = rchtxtFrase.Text.Length;
            while (cont < tamanho)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[cont]))
                {
                    qntdEspaco = qntdEspaco + 1;
                    cont++;
                }
                else
                    cont++; 
            }
            MessageBox.Show("Sua frase tem " + qntdEspaco + " espaços em branco.");
        }

        private void btnLetrasRep_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text;
            int cont = 0;
             
        }

        private void rchtxtFrase_TextChanged(object sender, EventArgs e)
        {
            if (rchtxtFrase.Text.Length > 100)
            {
                MessageBox.Show("Frase inválida (Max 100 letras)");
                rchtxtFrase.Focus();
            }
        }
    }
}

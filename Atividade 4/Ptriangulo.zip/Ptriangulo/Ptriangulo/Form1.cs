﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        Double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB))
            {
                MessageBox.Show("Entrada inválida");
                txtLadoB.Focus();
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Entrada inválida");
                txtLadoC.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (ladoA < (ladoB + ladoC) && ladoA > (Math.Abs(ladoB - ladoC)) && ladoB < (ladoA + ladoC)
               && ladoB > (Math.Abs(ladoA - ladoC)) && ladoC < (ladoA + ladoB) && ladoC > (Math.Abs(ladoA - ladoB)))
            {
                if (ladoA == ladoB && ladoB == ladoC)
                    MessageBox.Show("Triangulo Equilátero");
                else
                {
                    if (!(ladoA == ladoB) && !(ladoB == ladoC) && !(ladoC == ladoA))
                    {
                        MessageBox.Show("Triangulo Escaleno");
                    }
                    else
                        MessageBox.Show("Triangulo Isósceles");
                }
            }
            else
                MessageBox.Show("Não caracteriza um triangulo");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA))
            {
                MessageBox.Show("Entrada inválida");
                txtLadoA.Focus();
            }
        }
    }
}
